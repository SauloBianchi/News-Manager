---
name: Broadsheet Editorial
colors:
  surface: '#fdf9f1'
  surface-dim: '#dddad2'
  surface-bright: '#fdf9f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3eb'
  surface-container: '#f1ede5'
  surface-container-high: '#ece8e0'
  surface-container-highest: '#e6e2da'
  on-surface: '#1c1c17'
  on-surface-variant: '#58413f'
  inverse-surface: '#31302b'
  inverse-on-surface: '#f4f0e8'
  outline: '#8b716e'
  outline-variant: '#dfbfbc'
  surface-tint: '#aa3531'
  primary: '#6a020a'
  on-primary: '#ffffff'
  primary-container: '#8b1e1e'
  on-primary-container: '#ff9d95'
  inverse-primary: '#ffb3ad'
  secondary: '#4f5e81'
  on-secondary: '#ffffff'
  secondary-container: '#c5d4fd'
  on-secondary-container: '#4d5b7e'
  tertiary: '#412e12'
  on-tertiary: '#ffffff'
  tertiary-container: '#5a4426'
  on-tertiary-container: '#d0b28c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#891c1d'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b7c6ee'
  on-secondary-fixed: '#0a1a3a'
  on-secondary-fixed-variant: '#384668'
  tertiary-fixed: '#feddb5'
  tertiary-fixed-dim: '#e1c19a'
  on-tertiary-fixed: '#291801'
  on-tertiary-fixed-variant: '#594325'
  background: '#fdf9f1'
  on-background: '#1c1c17'
  surface-variant: '#e6e2da'
typography:
  display-masthead:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-masthead-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lead:
    fontFamily: Playfair Display
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  dateline:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system projects gravitas, literary precision, and journalistic integrity. It translates the legacy of historic broadsheet print rooms into a high-utility publishing administration platform. The aesthetic rejects decorative digital gradients and excessive floating layers in favor of structured typography, typographic discipline, ink-density variation, and razor-sharp hairline column rules.

The target audience comprises managing editors, copy chiefs, desk reporters, and digital publishing directors who balance high-speed digital publishing with high literary standards. The interface balances tactile, archival calm with data-dense editorial utility.

The design movement is **Editorial Realism & Classical Modernism**: an intentional digital adaptation of hot-metal typesetting traditions, featuring warm newsprint tones, structured multi-column grids, explicit dividing rules, and uncompromising typographic hierarchy.

## Colors

The color palette reflects physical print materials: raw paper stock, printing press ink, and editorial redlining pens.

- **Background Canvas (`#F4F0E8` / `#FBF9F5`):** Warm, unbleached newsprint stock provides eye comfort over long editorial shifts and eliminates stark digital glare.
- **Card & Surface (`#FFFFFF`):** Crisp editorial plates set directly against the off-white canvas to separate operational workflows cleanly.
- **Text Primary (`#111111`):** High-density carbon print ink used for headlines, dominant data fields, and primary body content.
- **Text Secondary (`#555555`):** Muted newsprint slate used for bylines, timestamps, helper descriptions, and metadata.
- **Primary Accent (`#8B1E1E`):** Editorial crimson red used purposefully for breaking news alerts, active state indicators, primary actions, and correction markers.
- **Secondary Accent (`#1B2A4A`):** Classic navy newsprint ink for navigation, edition selectors, and reference links.
- **Hairline Rules & Dividers (`#D5CEBF` / `#E2DDD3`):** Micro-fine paper seams separating columns, table rows, and panel sections.

## Typography

Typography establishes the authoritative broadsheet structure. Contrast between classical serif display faces and systematic, neutral sans-serif data displays ensures high reading comprehension and administrative clarity.

- **Headlines & Editorial Content (`Playfair Display`):** Reserved for publication titles, article decks, story previews, and primary desk headers. Italic variants are strictly used for edition subtitles, lead quotes, and column series flags.
- **Administrative Utilities & Tables (`Inter`):** All form controls, metrics, column data tables, bylines, and user actions run on neutral grotesque sans-serif to preserve scannability and compact density.
- **Datelines & Section Tags:** Handled exclusively through uppercase tracking (`label-caps` and `dateline`) to evoke classic broadsheet section flags (e.g., `NATIONAL DESK`, `VOL. CLXXIII`, `OP-ED`).

## Layout & Spacing

The layout is built on a structured **12-column broadsheet grid** inspired by physical newspaper paste-up boards.

- **Canvas & Desks:** Desktop environments run on a max-width container of `1440px` with `2rem` outer margins. Content breaks along vertical multi-column lines separated by `1.5rem` gutters.
- **Editorial Sub-Grids:** The dashboard splits typically into a 3-column broadsheet configuration: Left rail (Index & Navigation, 2 columns), Center well (Active Desk & Draft Manager, 7 columns), and Right rail (Publishing Schedule, Metadata & Wire Feeds, 3 columns).
- **Responsive Adaptations:**
  - **Desktop (1024px+):** Full 12-column view with simultaneous index, composing canvas, and desk sidebars.
  - **Tablet (768px - 1023px):** 8-column layout. The right rail slides off-canvas into an inspect drawer; gutters compress to `1rem`.
  - **Mobile (< 768px):** Single-column stacked broadsheet view with outer margins of `1rem`. Column rules pivot from vertical borders to horizontal dividing rules between modules.

## Elevation & Depth

This design system avoids soft, floating neomorphic shadows and glassy blurs. Depth is achieved via **tonal stacking, structural registration, and hairline rules**.

1. **Base Tier (Ground):** `#F4F0E8` unbleached paper surface.
2. **Sheet Tier (Cards & Workbenches):** `#FFFFFF` crisp paper tiles layered flat over ground with 1px border rules (`#D5CEBF`).
3. **Framing & Partitioning:** Visual distinction relies on architectural lines:
   - Single Hairline: `1px solid #D5CEBF` for subtle row splits and card borders.
   - Heavy Editorial Rule: `2px solid #111111` to seal section mastheads or separate primary leads from secondary stories.
   - Double Rule: A top `2px` black stroke separated by `2px` white gap and an underlying `1px` stroke, directly referencing classical newspaper mastheads.
4. **Modal / Popover Depth:** Only when dialog overlays are active does an elevation rule engage: a crisp, directional stamp shadow (`0 4px 0 0 #D5CEBF`, `0 0 0 1px #111111`) with no feathering, preserving the ink-on-paper discipline.

## Shapes

The shape system is strictly **Sharp (0px corner radius)**. 

Curves are completely absent from panels, text inputs, buttons, tables, tags, and tabs. Every container mimics the cut edge of raw newsprint and physical layout galleys. This hard rectilinear discipline sharpens administrative focus, preserves precise column alignment, and honors traditional print geometry.

## Components

### Masthead Header
The primary application top bar mimics the banner of a major daily newspaper:
- Features the system dateline: day of week, full date, edition number, and desk status (`VOL. CLXXIV NO. 42 | MORNING EDITION`).
- Centered or left-anchored title set in high-contrast `Playfair Display`.
- Framed on the bottom by a classic double horizontal hairline rule (`2px` black stroke, `2px` paper gap, `1px` boundary rule).

### Buttons & Editorial Actions
- **Primary Publish Action:** Deep crimson background (`#8B1E1E`), pure white uppercase sans-serif text, 0px radius, with subtle dark red hover (`#701616`).
- **Secondary Actions (Save Draft, Preview):** White paper background, `1px solid #111111` border, black text. Invert to solid `#111111` with white text on hover.
- **Tertiary Utility Actions:** Text-only, small caps with custom underline rule styled like traditional editorial annotations.

### Cards (Newspaper Ledger Cards)
- Grounded on crisp `#FFFFFF` backgrounds bound by `1px solid #D5CEBF`.
- Includes an uppercase category kicker (`label-caps`) in `#8B1E1E`, followed by a serif headline (`Playfair Display`), author byline, and word count tally.
- Card footers feature status stamps: `FILED`, `PROOFED`, `READY TO EMBARGO`, or `PUBLISHED`.

### Form Inputs & Editorial Controls
- Text inputs resemble blank print galleys: `#FFFFFF` surface, sharp corners, and a persistent `1px solid #D5CEBF` border that shifts to `1px solid #111111` on focus.
- Floating focus rings are strictly prohibited; selection is represented by high-contrast black border frames.
- Article body inputs support monospaced and editorial serif viewing modes with subtle live character and column-inch counters.

### Lists & Column Tables
- Dense, tabular data representations formatted with alternating light paper striping (`#FFFFFF` and `#FAF7F0`).
- Headers set in bold `label-caps` with a `2px solid #111111` bottom border.
- Rows separated by hairline rules (`1px solid #E2DDD3`).

### Category Chips & Status Badges
- Sharp rectangular boxes (`border: 1px solid #111111`, no radius).
- Backgrounds remain `#FFFFFF` or `#F4F0E8` with black text, or crimson outline for urgent breaking wire posts. No soft pastel pill tags.

### Publication Analytics & Crisp Visuals
- Metric displays present stats in ink-dense serif numbers paired with minimal high-contrast bar charts.
- Chart lines and bars use primary crimson (`#8B1E1E`), slate gray (`#555555`), and black ink (`#111111`) on top of faint hairline grid references.